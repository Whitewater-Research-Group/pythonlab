import pytest
from quadratic_solver import quadratic_solver

def test_two_real_roots():
    result_type, roots = quadratic_solver(1, -3, 2)  # x^2 - 3x + 2 = 0
    assert result_type == "Two Real Roots"
    assert set(round(r, 2) for r in roots) == {1.0, 2.0}

def test_one_real_root():
    result_type, roots = quadratic_solver(1, 2, 1)  # x^2 + 2x + 1 = 0
    assert result_type == "One Real Root"
    assert roots == (-1.0,)

def test_complex_roots():
    result_type, roots = quadratic_solver(1, 2, 5)  # discriminant < 0
    assert result_type == "Two Complex Roots"
    assert all(isinstance(r, complex) for r in roots)

def test_invalid_a():
    with pytest.raises(ValueError):
        quadratic_solver(0, 2, 1)
