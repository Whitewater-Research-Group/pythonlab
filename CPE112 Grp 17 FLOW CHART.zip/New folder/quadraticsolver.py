import cmath  # handles both real and complex roots

def quadratic_solver(a: float, b: float, c: float):
    """Solve quadratic equation ax^2 + bx + c = 0"""
    if a == 0:
        raise ValueError("Coefficient 'a' cannot be zero for a quadratic equation.")

    discriminant = b**2 - 4*a*c
    root1 = (-b + cmath.sqrt(discriminant)) / (2*a)
    root2 = (-b - cmath.sqrt(discriminant)) / (2*a)

    if discriminant > 0:
        return ("Two Real Roots", (root1.real, root2.real))
    elif discriminant == 0:
        return ("One Real Root", (root1.real,))
    else:
        return ("Two Complex Roots", (root1, root2))

if __name__ == "__main__":
    # Example run
    a = float(input("Enter a: "))
    b = float(input("Enter b: "))
    c = float(input("Enter c: "))

    result_type, roots = quadratic_solver(a, b, c)
    print(result_type)
    print("Roots:", roots)
